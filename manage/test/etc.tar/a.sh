#!/bin/bash
echo $*'#'
